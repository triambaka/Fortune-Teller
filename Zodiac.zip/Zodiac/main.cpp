#include<iostream>
#include<string>
#include<fstream>
#include<cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include "zodiac.cpp"
#include "p1.cpp"
#include "pro.cpp"


int main(){
    int choice;
    int date,mon;
    char name[25];
    cout<<"                -----------------Welcome to Fortune Teller------------------"<<endl;
    cout<<"      You can find out more about what's in store for you..what the future holds for you "<<endl;
    cout<<"                It's going to be fun ride...so hang in there!!"<<endl;
    cout<<"----------------------------------------------------------------------------"<<endl;
    cout<<"Enter to know to know about the following:"<<endl;
    cout<<"Before we start please follow the instructions and enter the necessary details"<<endl;
    cout<<"Enter your firstname"<<endl;
    cin>>name;
    cout<<"Enter the birth date "<<endl;
    cin>>date;
    cout<<"Enter the month"<<endl;
    cin>>mon;
    cout<<"1.Personality"<<endl<<"2.General"<<endl<<"3.Education and career"<<endl;
    cin>>choice;
    for(int i=0;i<strlen(name);i++)
        name[i]=tolower(name[i]);
    while(choice){
        if(choice==1){
            check(date);
        }
        else if(choice==2){
            zodiac(name,date,mon);
            
        }
        else if(choice==3){
            name1(name);
        }
        cout<<"1.Personality"<<endl<<"2.General"<<endl<<"3.Education and career"<<endl<<"4.Exit"<<endl;
        cin>>choice;
        if(choice==4){
            cout<<"It was nice to meet you!"<<endl<<"Come again to get intrigued by my mystic powers!";
            break;
        }
    }

}