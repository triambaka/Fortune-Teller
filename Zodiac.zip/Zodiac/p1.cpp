#include<iostream>
#include<fstream>
#include<string>
#include<cstdlib>
#include<ctime>
#include <cctype>
#include <cstring>
#include <cstdio>
using namespace std;

void name1(char name[])
{ 
ofstream fi;
fi.open("result.txt",std::fstream::in | std::fstream::out | std::fstream::app);
fi<<name<<"\n";
if (name[0]=='a'||name[0]=='g'||name[0]=='m'||name[0]=='s')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="a,g,m,s")
        {    getline(fin,read);
             while(!read.empty())
            {
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();


}
if (name[0]=='b'||name[0]=='h'||name[0]=='n'||name[0]=='t')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="b,h,n,t")
        {    getline(fin,read);
             while(!read.empty())
            {
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();
}
if (name[0]=='c'||name[0]=='i'||name[0]=='o'||name[0]=='u')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="c,i,o,u")
        {getline(fin,read);
             while(!read.empty())
            {
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();
}
if (name[0]=='d'||name[0]=='j'||name[0]=='p'||name[0]=='v')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="d,j,p,v")
        {getline(fin,read);
             while(!read.empty())
            {
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();
}
if (name[0]=='e'||name[0]=='k'||name[0]=='q'||name[0]=='w')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="e,k,q,w")
        {    getline(fin,read);
             while(!read.empty())
            {
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();
}
if (name[0]=='f'||name[0]=='l'||name[0]=='r'||name[0]=='x')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="f,l,r,x")
        {    getline(fin,read);
             while(!read.empty())
            {
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();
}
if (name[0]=='y'||name[0]=='z')
{
string read;
ifstream fin;
fin.open("name.txt");
    getline(fin,read);
     while(fin)
    {              
        if(read=="y,z")
        {
             while(!read.empty())
            {	getline(fin,read);
                cout<<read<<endl;
                fi<<read<<"\n";
                getline(fin,read);
            }
            break;
        }
        getline(fin,read);

    }
fin.close();
}
fi.close();
}
/*
int main()
{
    char name[25];
    cout<<"Enter your name!"<<endl;
    cin>>name;
    for(int i=0;i<strlen(name);i++)
        name[i]=tolower(name[i]);
    name1(name);
}
*/