#include<iostream>
#include<string>
#include<fstream>
#include<cstdlib>
#include <ctime>

using namespace std;
class Zodiac{
    public:int date;
    int mon;
    int year;
    string s;
    Zodiac(int dat, int month, string sign){
        date=dat;
        mon=month;
        s=sign;}
    void about(char []);
};
void Zodiac::about(char name[]){
        int a;
        string line;
        if(s=="Aquarius"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Aquarius"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
        }
        }
        else if(s=="Pisces"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Pisces"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }
            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
        }
        }
        if(s=="Aries"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       if(read=="Aries"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }
            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
        }
    }
        if(s=="Taurus"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Taurus"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
            }
        }
    if(s=="Gemini"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Gemini"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
            }
        }
        if(s=="Cancer"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Cancer"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
            }
        }
        if(s=="Leo"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Leo"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
        }
        }
    if(s=="Virgo"){
        while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Virgo"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
        }
        }
    if(s=="Libra"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Libra"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
            }
        }
    if(s=="Scorpio"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Scorpio"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
            }
        }
    if(s=="Sagittarius"){
        while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Sagittarius"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
        }
        }
    if(s=="Capricorn"){
            while(a!=0){
            cout<<endl<<"Enter"<<endl<<"1. About"<<endl<<"2.Predictions"<<endl<<"0.Exit"<<endl;
            cin>>a;
            if(a==1){
                string read;
                ifstream fin;
                fin.open("zodiac.txt");
                getline(fin,read);
                while(fin){
                       
                       if(read=="Capricorn"){
                           while(!read.empty()){
                               cout<<read<<endl;
                               getline(fin,read);
                           }
                        break;
                       }
                    getline(fin,read);

                }
                fin.close();
            }

            else if(a==2){
                string line; 
                ifstream fin; 
                int random;
                int numOfLines= 0;
                fin.open("Predictions.txt");

                while (fin) { 
                    srand(time(NULL));
                    int num= (rand() %17);
                    while(getline(fin, line)){
                        ++numOfLines;
                        if(numOfLines == num){
                            cout << line;
                        }
                    }
                }
                fin.close();
            }
            else{
                break;
            }
            }
        }
        return;
}