#include<iostream>
#include<string>
#include<fstream>
#include<cstdlib>
#include "new.cpp"

using namespace std;
/*typedef struct bd
{
    int date;
    int year;
    int mon;
}Bd;*/

void zodiac(char name[],int date,int mon){
    string s;
    //cout<<e.date<<"/"<<e.mon<<endl;
    if((date>=20 && mon==1)||(date<=18 && mon==2)){
        s="Aquarius";
        
        cout<<"Aquarius"<<endl;
        cout<<"/\\/\\/"<<endl;
        cout<<"/\\/\\/"<<endl;
        
    }
    
    else if((date>=19 && mon==2)||(date<=20 && mon==3)){
        s="Pisces";
        cout<<"Pisces"<<endl;
        cout<<"-)-(-"<<endl;
    }
    else if((date>=21 && mon==3)||(date<=19 && mon==4)){
        s="Aries";
        cout<<"Aries"<<endl;
        cout<<" _   _"<<endl;
        cout<<"' \\ / '"<<endl;
        cout<<"   V"<<endl;

    }
    else if((date>=20 && mon==4)||(date<=20 && mon==5)){
        s="Taurus";
        cout<<"Taurus"<<endl;
        cout<<"',_,' "<<endl;
        cout<<" (_)"<<endl;
    }
    else if((date>=21 && mon==5)||(date<=20 && mon==6)){
        s="Gemini";
        cout<<"Gemini"<<endl;
        cout<<" _____"<<endl;
        cout<<"  | |"<<endl;
        cout<<" _|_|_"<<endl;
        //cout<<""
    }
    else if((date>=21 && mon==6)||(date<=22 && mon==7)){
        s="Cancer";
        cout<<"Cancer"<<endl;
        cout<<".---,"<<endl;
        cout<<"O  O"<<endl;
        cout<<"`---'"<<endl;

    }
    
    else if((date>=23 && mon==7)||(date<=22 && mon==8)){
        s="Leo";
        cout<<"Leo"<<endl;
        cout<<" __"<<endl;
        cout<<"(  )"<<endl;
        cout<<" , /"<<endl;
        cout<<"O /"<<endl;
        cout<<"  '_,"<<endl;
    }
    else if((date>=23 && mon==8)||(date<=22 && mon==9)){
        s="Virgo";
        cout<<"Virgo"<<endl;
        cout<<"'_____"<<endl;
        cout<<" | | |/\\"<<endl;
        cout<<" | | | /"<<endl;
        cout<<"     -\\"<<endl;
        //cout<<"        \\"<<endl;

    }
    else if((date>=23 && mon==9)||(date<=22 && mon==10)){
        s="Libra";
        cout<<"Libra"<<endl;
        cout<<"  _"<<endl;
        cout<<"='-'="<<endl;

    }
    else if((date>=23 && mon==10)||(date<=21 && mon==11)){
        s="Scorpio";
        cout<<"Scorpio"<<endl;
        cout<<" _____"<<endl;
        cout<<" | | |"<<endl;
        cout<<" | | |"<<endl;
        cout<<"      \\"<<endl;
        cout<<"      \\/"<<endl;

    }
    else if((date>=22 && mon==11)||(date<=21 && mon==12)){
        s="Sagittarius";
        cout<<"Sagittarius"<<endl;
        cout<<"   __"<<endl;
        cout<<"    /|"<<endl;
        cout<<"  \\/"<<endl;
        cout<<"  /\\"<<endl;
    }
    else if((date>=22 && mon==12)||(date<=219 && mon==1)){
        s="Capricorn";
        cout<<"Capricorn"<<endl;
        cout<<"_     _" <<endl;
        cout<<" \\  /  )"<<endl;
        cout<<"  \\/   | _"<<endl;
        cout<<"        (_)"<<endl;
        cout<<"      _/ "<<endl;
    }
    else{
        cout<<"Incorrect details entered"<<endl;
        return;
    }
    Zodiac e(date,mon,s);
    e.about(name);
    ofstream myfile;
    myfile.open ("result.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    myfile << name<<"\n";
    myfile<<date<<" \\"<<mon<<"\n";
    myfile<<s<<"\n";
    myfile<<"\n\n\n";
    myfile.close();

    return ;
}

