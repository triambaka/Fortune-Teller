#include<iostream>
#include<fstream>
using namespace std;
void birth_Date();
void check(int number)
{/*
	cout<<"Enter birth date"<<endl;
	int number,date;
	cin>>number;
    */
   int date;
	if(number>=1&& number <=31)
	{
		int n1,n2,n3,n4,n5,n6;
		n1=number%10;
		number/=10;
		n2=number%10;
		number/=10;
		n3=n1+n2;
		n4=n3%10;
		n3/=10;
		n5=n3%10;
		n3/=10;
		date=n4+n5;
		cout<<"When your birth date is split and added = "<<date<<endl;
	}
	else if(number<1 && number >31)
	{
		cout<<"Please enter the correct date of birth"<<endl;
		cin>>number;
		
	}
	else 
	{
		cout<<"Please enter the correct date of birth"<<endl;
		cin>>number;
	}
	switch(date)
	{
		case 1:cout<<"In numerology number one is for independence."<<endl<<"One is blessed with a clear sense of purpose."<<endl<<"When a one decides to do something,nothing can get in the way."<<endl;
		          cout<<"Ones have the potential to become great leaders if they can channel their single-minded energies,but they usually cannot show empathy."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You are a leader."<<endl<<"You have great ambition and a strong drive for success."<<endl<<"You are highly independent and dislike the restrictions of having to work with others."<<endl<<"You easily become frustrated with the routine."<<endl<<"You are a pioneer,an initiator."<<endl<<"You are very creative; you possess a keen and rapid mind."<<endl<<"You have excellent business instincts, and with the appropriate training you can run large organizations and big businesses."<<endl<<"You use information for a specific purpose."<<endl<<"Knowledge is a practical tool in your hands,you dislike information or knowledge for its own sake."<<endl;
		          cout<<"You possess a broad vision and a great capacity for motivating others."<<endl<<"You have great will power that will be tested, especially during the years 28 to 56."<<endl<<"But your opportunity for accomplishment is enormous."<<endl<<"Your determination, will power, and inventiveness are the keys to your success and will likely bring you much personal reward and financial success."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You are generally open to the ideas of others, but you can be extremely stubborn and hardheaded once you become attached to your plans."<<endl<<"Avoid laziness and procrastination."<<endl<<"You are given to anger and frustration, and have a tendency to force the issue at times when things are not developing as rapidly as you would like."<<endl;
		          break;
		case 2:cout<<"The number two corresponds to a considerate nature."<<endl<<"Twos show strengths in many of the areas where others are weak."<<endl<<"They know how to work with others,and can often resolve conflicts."<<endl;
		          cout<<"Twos can usually see both sides of the issue,and be either indecisive or great at solving problems"<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You are very sensitive, intuitive, and diplomatic."<<endl<<"You may also possess artistic and musical ability."<<endl<<"You are warm and affectionate and need the same from your close friends and loved ones."<<endl<<"You are very cooperative and work best in partnerships."<<endl<<"You enjoy being the power behind the throne, rather than the figure on stage."<<endl<<"You are modest and kind. You have great diplomatic skills."<<endl<<"Your intuition allows you to perceive what another wants even before he or she says it."<<endl<<"You can continue a project better than start it."<<endl<< "You are very attentive to details. You need harmonious and peaceful environments."<<endl;
		          cout<<"You are the glue that keeps important projects and groups together."<<endl<<"While you may not get all the credit you deserve, you are indispensable in any endeavor."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You can fall victim to depression and lack of confidence."<<endl<<"Without balance, you can easily become stressed and high-strung."<<endl;
		          break;
		case 3:cout<<"The number three tend to be more social."<<endl<<"With their sparking wit and social skills,threes are meant to be the life of the party and often are."<<endl<<"They are very creative,honing almost any profession into art."<<endl;
		          cout<<"They get energy from the people and the world around them,which can sometimes result in a lack of direction."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You have a highly developed creative talent.You are an artist at heart."<<endl<<"You could excel in writing, visual or performing arts."<<endl<<"If you are not professionally involved in one of these areas, you should consider taking up art as a hobby."<<endl;
		          cout<<"You are highly imaginative, quick witted and possess the gift of gab."<<endl<<"You have great enthusiasm. Others find you inspiring and charming."<<endl<<"You are a wonderful salesperson. You are friendly and sociable, affectionate and loving."<<endl<<"You possess a good deal of charisma."<<endl;
		          cout<<"You have a fine sense of harmony and art in everything that you do, from your dress to the way you decorate your home."<<endl<<"You have a gift with plants and flower arranging."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You can be moody and subject to rapid ups and downs."<<endl<<"Be careful not to waste time and energy on trivial matters."<<endl<<"Keep your long-term priorities in perspective."<<endl;
		         
		case 4:cout<<"People associated with the number four are the practical sort."<<endl<<"Fours are dependable and grounded in innumerable ways."<<endl<<"They have a steadiness that allows them to follow conclusions through to the end-fours do well religious and scientific professions."<<endl<<"They are successful in whatever life deals with them."<<endl<<"However,that success may take time to come."<<endl;
		          cout<<"While fours are generally practical,they don't like contradictions and can be a little rigid."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You are a hard worker and a conscientious person."<<endl<<"You are precise and take great care in what you do."<<endl<<"You are highly-principled, disciplined, and responsible."<<endl<<"You take your obligations very seriously. You are highly ethical."<<endl<<"You are constantly focused on the foundations of your life - whether it is in business, career, or family matters, you take care of the basics."<<endl;
		          cout<<"You also like to be in nature. You are a natural organizer and manager."<<endl<< "People - especially relatives and co-workers - tend to rely on you. You are perceived as the rock of any endeavor."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You can be stubborn and rigid. Your nature is to dig in and wait."<<endl<<"This can close you off from solutions or creative ideas."<<endl<<"You must work at being more flexible. You often experience frustrations and repression."<<endl<<"You are not an emotional person, and perhaps you don't fully understand the emotional realm."<<endl<<"This is the reason you can be rather tactless at times."<<endl<<"Be careful to avoid excess work and missing out at smelling the roses of life."<<endl;
		          break;
		case 5:cout<<"The number 5 is associated with visionary natures."<<endl<<"Fives are the free souls who love adventure."<<endl<<"They often find it hard to stick around."<<endl<<"They are successful in whatever life deals them."<<endl<<"However,that success may take time to come."<<endl;
		          cout<<"To be happy,they need to find a place in life that they feel allows them to be free."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You are highly-adaptable and need excitement."<<endl<<"You relate well to others and have an easy way with words."<<endl<<"In fact, you have a talent for promotion, public relations, and, for some, writing. Your social skills are highly refined."<<endl<<"Your ability to communicate and promote a product or event makes you a natural salesperson."<<endl<<"You work well with others as long as there are not too many restrictions."<<endl<<"You have trouble being bound to a desk or within an office."<<endl<<"You can easily feel cooped up and trapped unless there is much variety and change in your life."<<endl;
		          cout<<"You become bored and restless easily."<<endl<<"You may be a little irresponsible and need to learn discipline and orderliness."<<endl<<"You have a quick and analytical mind."<<endl<<"You may be over-confident and headstrong, however, you are highly creative and can usually come up with a remarkably workable solution to most problems -- either your own or those of others."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You can be impatient and impulsive."<<endl<<"You can also overindulge your senses in food."<<endl<<"You must be careful to protect your health from the excesses of your tastes."<<endl;
		          break;
		case 6:cout<<"The number six stands for responsibility."<<endl<<"Sixes are known for their nurturing nature."<<endl<<"They want to takecare of everyone  around them,which develops them into a person who is both fair and has a sense of righteousness."<<endl;
		          cout<<"Sixes often do well in humanitarian roles."<<endl<<"However,they must take guard to keep their protective natures in  check."<<endl<<"Otherwise,they may become too controlling or self -sacrifising."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You are family-oriented and have a talent for settling disputes between people to the satisfaction of both sides."<<endl<<"You somehow know the middle ground. Your lesson in life is to work with the whole subject of balance."<<endl<<"You must come to truly understand the ancient and fundamental principle of opposites that seek harmony."<<endl<<"Whether the realm is the emotions, caring for others, finances, work, or play, you must learn where you can be of service, exactly what you can do, and what are your limits."<<endl;	
		          cout<<"You have a considerable amount of artistic talent."<<endl<<"You have a deep appreciation of beauty and art."<<endl<<"You are highly responsible and will do without in order to fulfill a debt."<<endl<<"Your focus is on relationships."<<endl<<"You want to help others, and have a talent as a healer and could make a profession of the healing arts, either as a nutritionist, alternative health therapist (acupuncture, massage, for example) or doctor."<<endl;
		          cout<<"YOUR CHALLENGES"<<endl;
		          cout<<"You need to know you are appreciated. You are given to flattery and vulnerable to praise."<<endl<<"Criticism, on the other hand, leaves a very damaging impression on you. You take it deeply to heart. "<<endl<<"You will sacrifice your own comfort to support and help others. You are generous, kind, and understanding."<<endl<<"You can be highly emotional and given to extremes in sympathy and sentimentality."<<endl<<"You must learn to provide more than merely a shoulder to cry on."<<endl<<"Study and the development of your healing skills brings you great rewards in life."<<endl;
		          break;
		case 7:cout<<"The number seven is visionary in nature."<<endl<<"Sevens have intellectual natures."<<endl<<"They are always in search of what is interesting or true."<<endl<<"Sevens are very observant as well,love to share their conclusions by lively debating their point,while others quitely analyze their observations from a corner."<<endl;
		          cout<<"Their greatest weakness,predictably,is overthinking a situation."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You possess a highly developed mind. It is your instrument for investigating the world and all its subjects."<<endl<<"You are philosophically and spiritually oriented."<<endl<<"You can and should specialize in one given field in order to make full use of your abilities and your natural intellectual gifts."<<endl<<"You tend to be analytical and rational in your approach to relationships."<<endl<<"Emotions are a cloudy and uncertain realm for you, which, very often, you do not trust."<<endl<<"Emotional people are sometimes viewed by you as a bit immature or unpredictable."<<endl;
		          cout<<"You have excellent intuition."<<endl<<"You should meditate and do some type of spiritual exercise in order to develop your intuitive talents."<<endl<<"You prefer to work alone and set your own pace."<<endl<<"You tend to finish projects once started. Your interest leans to the scientific, technical and metaphysical."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You are very sensitive and feel deeply, but you do not share your feelings easily and do not communicate them well."<<endl<<"You like to spend time alone, but have to be careful not to become too withdrawn."<<endl<<"You can be opinionated and stubborn. You must guard against becoming too analytical, cold-hearted and cynical."<<endl<<"You can be highly critical and self-centered  traits that can lead to much unhappiness, especially in marriage, if you are not careful. Once married, you tend to be loyal and faithful."<<endl;
		          cout<<"Make the most of your gifts of mind without losing your heart in the process."<<endl<<"Share your emotions with those you trust, and maintain long-lasting close relationships."<<endl<<"This will balance your mental life and will be a source of great comfort."<<endl;
		          break;
		case 8:cout<<"The number eight stands for ambition."<<endl<<"Eights are often very financially successful in life."<<endl<<"However they are more practical."<<endl<<"This practicality can lead to business success because it helps them in planning and preparing,but they often question their ,materialism,and this allows them to be well balanced."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You have a talent for business, and a good sense of money."<<endl<<"Your approach to business is original, creative and daring."<<endl<<"You have sound judgment and need the freedom to exercise it, lest you become bitter and tyrannical elsewhere in your life."<<endl<<"You are highly competitive.You are efficient and can handle large projects."<<endl<<"If you do not already run your department or own business, you are destined for such a position."<<endl<<"Leadership is your gift. In the same way, you have a great talent for organization."<<endl<<"You can manage large groups of people and guide them along the lines of your vision."<<endl<<"You are a realist, self-confident, practical, ambitious and goal-oriented."<<endl<<"Others respect you and your judgment. They know that you can be depended upon,you come through."<<endl;
		          cout<<"You enjoy a challenge. The expectations of others stimulate you, especially if they doubt you can pull it off."<<endl<<"You tend to be dramatic with money. You have a need for status and may show off the fruits of your labor with an impressive car or house. "<<endl<<"You are proud of your family and like to be complemented."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"You have strong character, but may be domineering and bossy."<<endl<<"You have little patience with weakness, be it your own or someone else's."<<endl<<"You do not express your feelings much."<<endl<<"You must develop the qualities of perseverance and survival."<<endl<<"You will meet many obstacles, which must be viewed as challenges that, in fact, make you stronger."<<endl<<"Your attitude toward the difficulties in life will be the difference between success and failure."<<endl;
		          break;
		case 9:cout<<"The number nine can be very selfless."<<endl<<"A nine always sees the bigger picture."<<endl<<"They are often natural givers because they see the intercorrectedness of everything."<<endl<<"They are hard on themselves,and when they see problems in society,they will dedicate themselves to fixing them."<<endl<<"Sometimes they have issues with the here and now."<<endl;
		          cout<<"YOUR STRENGTHS:"<<endl;
		          cout<<"You are broad-minded, idealistic and compassionate."<<endl<<"You should obtain a wide education, especially in the arts. You are highly creative."<<endl<<"Many great artists are found under this number.Your must come to truly understand life to be of greater service to society."<<endl<<"You have a greater social role to play that will require a blend of the practical and humanitarian efforts."<<endl<<"You must have a keen sense of what will work, but at the same time directing those efforts toward some greater good."<<endl<<"Your challenge is to find a place for yourself that has some direct benefit to others."<<endl<<"The more you can be of service to humanity, the greater will be your personal reward on all levels -- from the material to the spiritual."<<endl;
		          cout<<"You are socially oriented and have a gift of charm."<<endl<<"You are well-liked and even admired by others."<<endl<<"You can relate to people in all walks of life."<<endl<<"You have a broad vision of the world and can see the grand scheme of things, including international politics and great social movements."<<endl<<"You express your feelings well, but sometimes can be a bit dramatic."<<endl<<"You have a strong interest in philosophy and metaphysics. 9s tend to attract money from other sources, such as inheritance or a stroke of  luck."<<endl;
		          cout<<"YOUR CHALLENGES:"<<endl;
		          cout<<"There is an element of sacrifice in the number 9 that demands that you learn forgiveness and unconditional love."<<endl<<"You must avoid negative attachments."<<endl<<"Do not hold on to people or situations because you feel that justice has not yet been done, or that someone still owes you something."<<endl<<"Your task in life is to truly let the universe judge such situations, and rely on your own forward-moving life path to bring you the necessities and rewards you deserve."<<endl;
		          break;
		default:exit(0);
	}
}